# Liquidador Web DIAN

## Overview

This is a tax liquidation web application for the Colombian tax authority (DIAN). The system calculates interest, penalties, and payment distributions based on Colombian tax regulations. It features a React frontend with a Node.js/Express backend, using Drizzle ORM for database operations and Python scripts for complex tax calculations.

## System Architecture

The application follows a full-stack architecture with clear separation between frontend, backend, and calculation logic:

- **Frontend**: React with TypeScript, using Vite for development and building
- **Backend**: Node.js with Express, serving both API endpoints and static files
- **Database**: PostgreSQL with Drizzle ORM for type-safe database operations
- **Calculations**: Python scripts for complex tax liquidation computations
- **UI Framework**: Tailwind CSS with Radix UI components via shadcn/ui

## Key Components

### Frontend Architecture
- **React SPA** with TypeScript for type safety
- **Component Library**: shadcn/ui components built on Radix UI primitives
- **State Management**: React Query for server state management
- **Routing**: Wouter for lightweight client-side routing
- **Forms**: React Hook Form with Zod validation
- **Styling**: Tailwind CSS with custom design system

### Backend Architecture
- **Express Server** handling API routes and static file serving
- **Database Layer**: Drizzle ORM with PostgreSQL for data persistence
- **File Upload**: Multer for handling CSV file uploads (tax rates and IPC data)
- **Python Integration**: Child process execution for tax calculation scripts

### Database Schema
- **liquidaciones**: Stores tax liquidation records with payment history
- **configuraciones**: Stores payment proportion configurations
- **JSON Fields**: Used for storing complex payment arrays and calculation results

### Tax Calculation Engine
- **Python Scripts**: Modular calculation system with separate files for:
  - Tax rates management (tasas.py)
  - IPC (inflation) calculations (ipc.py)
  - Business rules (reglas.py)
  - Main liquidation logic (liquidacion.py)

## Data Flow

1. **User Input**: Tax information entered through React forms
2. **Validation**: Client-side validation with Zod schemas
3. **API Processing**: Express server validates and stores data
4. **Calculation**: Python scripts process tax calculations using uploaded rate files
5. **Results Storage**: Calculated results stored back to database
6. **Display**: Results rendered in interactive tables and summary cards

## External Dependencies

### Node.js Dependencies
- **React Ecosystem**: React, React DOM, Vite for development
- **UI Components**: Radix UI primitives, Lucide icons
- **Database**: Drizzle ORM, Neon Database connector
- **Forms & Validation**: React Hook Form, Zod
- **HTTP Client**: TanStack Query for API state management
- **File Processing**: Multer for uploads
- **Styling**: Tailwind CSS, class-variance-authority

### Python Dependencies
- **pandas**: For CSV data processing
- **datetime**: For date calculations
- **json**: For data serialization

### Data Files
- **tasas_dian.csv**: Official DIAN tax rates by date range
- **ipc.csv**: Annual inflation rates for penalty adjustments

## Deployment Strategy

The application is configured for deployment on Replit with the following setup:

- **Development**: `npm run dev` starts Vite dev server with HMR
- **Production Build**: `npm run build` creates optimized production bundle
- **Production Start**: `npm run start` serves built application
- **Database**: PostgreSQL module configured in Replit environment
- **Port Configuration**: Application runs on port 5000, exposed as port 80

The build process:
1. Vite builds the React frontend to `dist/public`
2. esbuild bundles the Express server to `dist/index.js`
3. Static files served from the built frontend directory

## Changelog

```
Changelog:
- June 26, 2025. Initial setup
```

## User Preferences

```
Preferred communication style: Simple, everyday language.
```