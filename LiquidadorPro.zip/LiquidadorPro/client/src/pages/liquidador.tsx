import { useState } from "react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Calculator, Settings, BarChart3 } from "lucide-react";
import LiquidacionForm from "@/components/liquidacion-form";
import ConfiguracionTab from "@/components/configuracion-tab";
import ResultadosTab from "@/components/resultados-tab";
import { ResultadoLiquidacion } from "@/lib/types";

export default function Liquidador() {
  const [resultados, setResultados] = useState<ResultadoLiquidacion | null>(null);
  const [liquidacionId, setLiquidacionId] = useState<number | null>(null);

  const handleCalculationComplete = (results: ResultadoLiquidacion, id: number) => {
    setResultados(results);
    setLiquidacionId(id);
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b border-gray-200 shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-blue-600 rounded-lg flex items-center justify-center">
                <Calculator className="text-white" size={20} />
              </div>
              <div>
                <h1 className="text-xl font-bold text-gray-900">Liquidador Web DIAN</h1>
                <p className="text-sm text-gray-500">Sistema de Liquidación Tributaria</p>
              </div>
            </div>
            <div className="flex items-center space-x-4">
              <button className="text-gray-500 hover:text-gray-700 transition-colors">
                <span className="ml-2 hidden sm:inline">Exportar</span>
              </button>
              <button className="text-gray-500 hover:text-gray-700 transition-colors">
                <span className="ml-2 hidden sm:inline">Ayuda</span>
              </button>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <Tabs defaultValue="liquidacion" className="w-full">
          <TabsList className="grid w-full grid-cols-3 mb-8">
            <TabsTrigger value="liquidacion" className="flex items-center gap-2">
              <Calculator size={16} />
              Liquidación
            </TabsTrigger>
            <TabsTrigger value="configuracion" className="flex items-center gap-2">
              <Settings size={16} />
              Configuración
            </TabsTrigger>
            <TabsTrigger value="resultados" className="flex items-center gap-2">
              <BarChart3 size={16} />
              Resultados
            </TabsTrigger>
          </TabsList>

          <TabsContent value="liquidacion">
            <LiquidacionForm onCalculationComplete={handleCalculationComplete} />
          </TabsContent>

          <TabsContent value="configuracion">
            <ConfiguracionTab />
          </TabsContent>

          <TabsContent value="resultados">
            <ResultadosTab resultados={resultados} liquidacionId={liquidacionId} />
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
