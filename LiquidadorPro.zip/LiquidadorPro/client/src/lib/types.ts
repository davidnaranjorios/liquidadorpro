export interface LiquidacionData {
  nit: string;
  razonSocial: string;
  concepto: string;
  anio: number;
  periodo: number;
  valorInicial: number;
  valorSancion: number;
  origenSancion: string;
  fechaVencimiento: string;
  fechaPresentacionSancion: string;
  tipoNorma: string;
  pagos: Array<{ fecha: string; valor: number }>;
}

export interface ConfiguracionProporciones {
  p1: { impuesto: number; intereses: number; sancion: number };
  p2: { impuesto: number; intereses: number; sancion: number };
  p3: { impuesto: number; intereses: number; sancion: number };
}

export interface ResultadoLiquidacion {
  historial: Array<{
    fecha_pago: string;
    monto_pago: number;
    tipo_proporcion: string;
    factor_proporcionalidad: number;
    impuesto_proporcion: number;
    intereses_proporcion: number;
    sancion_proporcion: number;
    impuesto_saldo: number;
    intereses_saldo: number;
    sancion_saldo: number;
    tasa_aplicada: number;
    dias_mora: number;
  }>;
  resumen: {
    impuesto_base: number;
    intereses_totales: number;
    sanciones_totales: number;
    total_pagado: number;
    saldo_impuesto: number;
    saldo_intereses: number;
    saldo_sancion: number;
    saldo_final: number;
  };
}
