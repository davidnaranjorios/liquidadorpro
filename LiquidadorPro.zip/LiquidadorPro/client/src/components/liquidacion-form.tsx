import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useMutation } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { AlertCircle, Building, File, TriangleAlert, Plus, Trash2, Calculator, Eraser } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { LiquidacionData, ResultadoLiquidacion } from "@/lib/types";

const liquidacionSchema = z.object({
  nit: z.string().min(1, "NIT es requerido"),
  razonSocial: z.string().min(1, "Razón social es requerida"),
  concepto: z.string().min(1, "Concepto es requerido"),
  anio: z.number().min(2018).max(2025),
  periodo: z.number().min(1).max(12),
  valorInicial: z.number().min(1, "Valor inicial debe ser mayor a 0"),
  valorSancion: z.number().min(0),
  origenSancion: z.string(),
  fechaVencimiento: z.string().min(1, "Fecha de vencimiento es requerida"),
  fechaPresentacionSancion: z.string().min(1, "Fecha de presentación es requerida"),
  tipoNorma: z.string().min(1, "Tipo de norma es requerido"),
  pagos: z.array(z.object({
    fecha: z.string().min(1, "Fecha es requerida"),
    valor: z.number().min(1, "Valor debe ser mayor a 0")
  })).min(1, "Debe agregar al menos un pago")
});

type LiquidacionFormData = z.infer<typeof liquidacionSchema>;

interface Props {
  onCalculationComplete: (results: ResultadoLiquidacion, id: number) => void;
}

export default function LiquidacionForm({ onCalculationComplete }: Props) {
  const { toast } = useToast();
  const [isLoading, setIsLoading] = useState(false);

  const form = useForm<LiquidacionFormData>({
    resolver: zodResolver(liquidacionSchema),
    defaultValues: {
      nit: "",
      razonSocial: "",
      concepto: "",
      anio: new Date().getFullYear(),
      periodo: 1,
      valorInicial: 0,
      valorSancion: 0,
      origenSancion: "Privada",
      fechaVencimiento: "",
      fechaPresentacionSancion: "",
      tipoNorma: "TASA DIAN",
      pagos: [{ fecha: "", valor: 0 }]
    }
  });

  const createLiquidacion = useMutation({
    mutationFn: async (data: LiquidacionData) => {
      const response = await apiRequest("POST", "/api/liquidacion", data);
      return response.json();
    }
  });

  const calculateLiquidacion = useMutation({
    mutationFn: async (id: number) => {
      const response = await apiRequest("POST", `/api/liquidacion/${id}/calcular`, {});
      return response.json();
    }
  });

  const onSubmit = async (data: LiquidacionFormData) => {
    try {
      setIsLoading(true);
      
      // Create liquidation
      const liquidacion = await createLiquidacion.mutateAsync(data);
      
      // Calculate results
      const results = await calculateLiquidacion.mutateAsync(liquidacion.id);
      
      onCalculationComplete(results, liquidacion.id);
      
      toast({
        title: "Cálculo completado",
        description: "La liquidación se ha calculado correctamente."
      });
      
    } catch (error) {
      toast({
        title: "Error",
        description: "Error al calcular la liquidación. Verifique los datos ingresados.",
        variant: "destructive"
      });
    } finally {
      setIsLoading(false);
    }
  };

  const addPago = () => {
    const currentPagos = form.getValues("pagos");
    form.setValue("pagos", [...currentPagos, { fecha: "", valor: 0 }]);
  };

  const removePago = (index: number) => {
    const currentPagos = form.getValues("pagos");
    if (currentPagos.length > 1) {
      form.setValue("pagos", currentPagos.filter((_, i) => i !== index));
    }
  };

  const clearForm = () => {
    form.reset();
    toast({
      title: "Formulario limpiado",
      description: "Todos los campos han sido reiniciados."
    });
  };

  const pagos = form.watch("pagos");
  const valorInicial = form.watch("valorInicial");
  const valorSancion = form.watch("valorSancion");
  const totalPagos = pagos.reduce((sum, pago) => sum + (pago.valor || 0), 0);
  const totalDeuda = valorInicial + valorSancion;

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
      {/* Left Column: Form */}
      <div className="lg:col-span-2 space-y-6">
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
            
            {/* Entity Information */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Building className="text-blue-600" size={20} />
                  Información del Contribuyente
                </CardTitle>
              </CardHeader>
              <CardContent className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="nit"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>NIT</FormLabel>
                      <FormControl>
                        <Input placeholder="123456789-0" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="razonSocial"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Razón Social</FormLabel>
                      <FormControl>
                        <Input placeholder="Empresa S.A.S." {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </CardContent>
            </Card>

            {/* Tax Information */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <File className="text-blue-600" size={20} />
                  Obligación Tributaria
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <FormField
                    control={form.control}
                    name="concepto"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Concepto</FormLabel>
                        <Select onValueChange={field.onChange} defaultValue={field.value}>
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="Seleccionar concepto" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value="IVA">IVA</SelectItem>
                            <SelectItem value="Renta">Renta</SelectItem>
                            <SelectItem value="ICA">ICA</SelectItem>
                            <SelectItem value="Retención en la Fuente">Retención en la Fuente</SelectItem>
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="anio"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Año</FormLabel>
                        <FormControl>
                          <Input 
                            type="number" 
                            min={2018} 
                            max={2025} 
                            {...field}
                            onChange={(e) => field.onChange(parseInt(e.target.value))}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="periodo"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Período</FormLabel>
                        <Select onValueChange={(value) => field.onChange(parseInt(value))} defaultValue={field.value?.toString()}>
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="Seleccionar período" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            {Array.from({ length: 12 }, (_, i) => (
                              <SelectItem key={i + 1} value={(i + 1).toString()}>
                                {new Date(0, i).toLocaleString('es', { month: 'long' })}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <FormField
                    control={form.control}
                    name="fechaVencimiento"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Fecha de Vencimiento</FormLabel>
                        <FormControl>
                          <Input type="date" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="valorInicial"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Valor del Impuesto</FormLabel>
                        <FormControl>
                          <Input 
                            type="number" 
                            placeholder="0"
                            {...field}
                            onChange={(e) => field.onChange(parseFloat(e.target.value) || 0)}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
              </CardContent>
            </Card>

            {/* Sanction Information */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <TriangleAlert className="text-amber-600" size={20} />
                  Información de Sanción
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <FormField
                    control={form.control}
                    name="valorSancion"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Valor de la Sanción</FormLabel>
                        <FormControl>
                          <Input 
                            type="number" 
                            placeholder="0"
                            {...field}
                            onChange={(e) => field.onChange(parseFloat(e.target.value) || 0)}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="origenSancion"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Origen de Sanción</FormLabel>
                        <Select onValueChange={field.onChange} defaultValue={field.value}>
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value="Privada">Privada</SelectItem>
                            <SelectItem value="Oficial">Oficial</SelectItem>
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="fechaPresentacionSancion"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Fecha Presentación</FormLabel>
                        <FormControl>
                          <Input type="date" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
                <FormField
                  control={form.control}
                  name="tipoNorma"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Tipo de Norma</FormLabel>
                      <Select onValueChange={field.onChange} defaultValue={field.value}>
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="TASA DIAN">TASA DIAN</SelectItem>
                          <SelectItem value="ART. 91 LEY 2277">ART. 91 LEY 2277</SelectItem>
                          <SelectItem value="ART 45 LEY 2155">ART 45 LEY 2155</SelectItem>
                          <SelectItem value="ART 48 LEY 2155">ART 48 LEY 2155</SelectItem>
                          <SelectItem value="ART 120 LEY 2010">ART 120 LEY 2010</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </CardContent>
            </Card>

            {/* Payments */}
            <Card>
              <CardHeader>
                <div className="flex justify-between items-center">
                  <CardTitle className="flex items-center gap-2">
                    <svg className="w-5 h-5 text-green-600" fill="currentColor" viewBox="0 0 20 20">
                      <path d="M4 4a2 2 0 00-2 2v4a2 2 0 002 2V6h10a2 2 0 00-2-2H4zm2 6a2 2 0 012-2h8a2 2 0 012 2v4a2 2 0 01-2 2H8a2 2 0 01-2-2v-4zm6 4a2 2 0 100-4 2 2 0 000 4z" />
                    </svg>
                    Pagos Realizados
                  </CardTitle>
                  <Button type="button" onClick={addPago} variant="outline" size="sm">
                    <Plus size={16} className="mr-2" />
                    Agregar Pago
                  </Button>
                </div>
              </CardHeader>
              <CardContent className="space-y-3">
                {pagos.map((_, index) => (
                  <div key={index} className="bg-gray-50 p-4 rounded-md border border-gray-200">
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      <FormField
                        control={form.control}
                        name={`pagos.${index}.fecha`}
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Fecha de Pago</FormLabel>
                            <FormControl>
                              <Input type="date" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      <FormField
                        control={form.control}
                        name={`pagos.${index}.valor`}
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Valor del Pago</FormLabel>
                            <FormControl>
                              <Input 
                                type="number" 
                                placeholder="0"
                                {...field}
                                onChange={(e) => field.onChange(parseFloat(e.target.value) || 0)}
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      <div className="flex items-end">
                        <Button
                          type="button"
                          variant="ghost"
                          size="sm"
                          onClick={() => removePago(index)}
                          disabled={pagos.length === 1}
                          className="text-red-600 hover:text-red-800"
                        >
                          <Trash2 size={16} />
                        </Button>
                      </div>
                    </div>
                  </div>
                ))}
                <div className="p-3 bg-blue-50 rounded-md">
                  <p className="text-sm text-blue-700 flex items-center gap-2">
                    <AlertCircle size={16} />
                    Los pagos se procesarán según las reglas de proporcionalidad establecidas por la DIAN.
                  </p>
                </div>
              </CardContent>
            </Card>
          </form>
        </Form>
      </div>

      {/* Right Column: Summary and Actions */}
      <div className="space-y-6">
        {/* Quick Summary */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Calculator className="text-blue-600" size={20} />
              Resumen Rápido
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="flex justify-between items-center py-2 border-b border-gray-100">
              <span className="text-sm text-gray-600">Impuesto Base:</span>
              <span className="font-medium text-gray-900">
                ${valorInicial?.toLocaleString() || 0}
              </span>
            </div>
            <div className="flex justify-between items-center py-2 border-b border-gray-100">
              <span className="text-sm text-gray-600">Sanción:</span>
              <span className="font-medium text-red-600">
                ${valorSancion?.toLocaleString() || 0}
              </span>
            </div>
            <div className="flex justify-between items-center py-2 font-semibold text-lg">
              <span className="text-gray-900">Total Deuda:</span>
              <span className="text-blue-700">
                ${totalDeuda?.toLocaleString() || 0}
              </span>
            </div>
            <div className="pt-4 border-t border-gray-200">
              <div className="flex justify-between items-center">
                <span className="text-sm text-gray-600">Total Pagos:</span>
                <span className="font-medium text-green-600">
                  ${totalPagos.toLocaleString()}
                </span>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Action Buttons */}
        <Card>
          <CardHeader>
            <CardTitle>Acciones</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <Button 
              onClick={form.handleSubmit(onSubmit)} 
              disabled={isLoading}
              className="w-full"
            >
              <Calculator className="mr-2" size={16} />
              {isLoading ? "Calculando..." : "Calcular Liquidación"}
            </Button>
            <Button 
              type="button" 
              variant="outline" 
              onClick={clearForm}
              className="w-full"
            >
              <Eraser className="mr-2" size={16} />
              Limpiar Formulario
            </Button>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
