import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { FileDown, FileSpreadsheet, BarChart3, DollarSign, Percent, AlertTriangle, CheckCircle } from "lucide-react";
import { ResultadoLiquidacion } from "@/lib/types";

interface Props {
  resultados: ResultadoLiquidacion | null;
  liquidacionId: number | null;
}

export default function ResultadosTab({ resultados }: Props) {
  if (!resultados) {
    return (
      <div className="flex flex-col items-center justify-center py-12">
        <BarChart3 className="w-16 h-16 text-gray-400 mb-4" />
        <h3 className="text-lg font-medium text-gray-900 mb-2">No hay resultados disponibles</h3>
        <p className="text-gray-500 text-center max-w-md">
          Complete el formulario de liquidación y presione "Calcular Liquidación" para ver los resultados aquí.
        </p>
      </div>
    );
  }

  const { historial, resumen } = resultados;

  const getProportionBadgeColor = (tipo: string) => {
    if (tipo.includes("Proporción 1")) return "bg-blue-100 text-blue-800";
    if (tipo.includes("Proporción 2")) return "bg-amber-100 text-amber-800";
    if (tipo.includes("Proporción 3")) return "bg-red-100 text-red-800";
    return "bg-green-100 text-green-800";
  };

  const getProportionLabel = (tipo: string) => {
    if (tipo.includes("Proporción 1")) return "Prop. 1";
    if (tipo.includes("Proporción 2")) return "Prop. 2";
    if (tipo.includes("Proporción 3")) return "Prop. 3";
    return "Pago Total";
  };

  return (
    <div className="space-y-6">
      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center">
              <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                <DollarSign className="text-blue-600" size={24} />
              </div>
              <div className="ml-4">
                <p className="text-sm text-gray-600">Impuesto Base</p>
                <p className="text-xl font-bold text-gray-900">
                  ${resumen.impuesto_base.toLocaleString()}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center">
              <div className="w-12 h-12 bg-amber-100 rounded-lg flex items-center justify-center">
                <Percent className="text-amber-600" size={24} />
              </div>
              <div className="ml-4">
                <p className="text-sm text-gray-600">Intereses</p>
                <p className="text-xl font-bold text-amber-600">
                  ${resumen.intereses_totales.toLocaleString()}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center">
              <div className="w-12 h-12 bg-red-100 rounded-lg flex items-center justify-center">
                <AlertTriangle className="text-red-600" size={24} />
              </div>
              <div className="ml-4">
                <p className="text-sm text-gray-600">Sanciones</p>
                <p className="text-xl font-bold text-red-600">
                  ${resumen.sanciones_totales.toLocaleString()}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center">
              <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
                <CheckCircle className="text-green-600" size={24} />
              </div>
              <div className="ml-4">
                <p className="text-sm text-gray-600">Total Pagado</p>
                <p className="text-xl font-bold text-green-600">
                  ${resumen.total_pagado.toLocaleString()}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Detailed Results Table */}
      <Card>
        <CardHeader>
          <div className="flex justify-between items-center">
            <CardTitle className="flex items-center gap-2">
              <BarChart3 className="text-blue-600" size={20} />
              Detalle de Liquidación por Pago
            </CardTitle>
            <div className="flex gap-2">
              <Button variant="outline" size="sm">
                <FileDown className="mr-2" size={16} />
                Exportar PDF
              </Button>
              <Button variant="outline" size="sm">
                <FileSpreadsheet className="mr-2" size={16} />
                Exportar Excel
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Fecha Pago</TableHead>
                  <TableHead>Monto Pago</TableHead>
                  <TableHead>Tipo Proporción</TableHead>
                  <TableHead>Impuesto</TableHead>
                  <TableHead>Intereses</TableHead>
                  <TableHead>Sanción</TableHead>
                  <TableHead>Saldo Final</TableHead>
                  <TableHead>Tasa</TableHead>
                  <TableHead>Días Mora</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {historial.map((pago, index) => (
                  <TableRow key={index} className="hover:bg-gray-50">
                    <TableCell className="font-medium">{pago.fecha_pago}</TableCell>
                    <TableCell>${pago.monto_pago.toLocaleString()}</TableCell>
                    <TableCell>
                      <Badge className={getProportionBadgeColor(pago.tipo_proporcion)}>
                        {getProportionLabel(pago.tipo_proporcion)}
                      </Badge>
                    </TableCell>
                    <TableCell>${pago.impuesto_proporcion.toLocaleString()}</TableCell>
                    <TableCell className="text-amber-600">
                      ${pago.intereses_proporcion.toLocaleString()}
                    </TableCell>
                    <TableCell className="text-red-600">
                      ${pago.sancion_proporcion.toLocaleString()}
                    </TableCell>
                    <TableCell className="font-medium">
                      ${(pago.impuesto_saldo + pago.intereses_saldo + pago.sancion_saldo).toLocaleString()}
                    </TableCell>
                    <TableCell>{(pago.tasa_aplicada * 100).toFixed(2)}%</TableCell>
                    <TableCell>{pago.dias_mora}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>

      {/* Calculation Details */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Final Balances */}
        <Card>
          <CardHeader>
            <CardTitle>Saldos Finales</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex justify-between items-center py-2 border-b">
              <span className="text-gray-600">Saldo Impuesto:</span>
              <span className="font-medium text-gray-900">
                ${resumen.saldo_impuesto.toLocaleString()}
              </span>
            </div>
            <div className="flex justify-between items-center py-2 border-b">
              <span className="text-gray-600">Saldo Intereses:</span>
              <span className="font-medium text-amber-600">
                ${resumen.saldo_intereses.toLocaleString()}
              </span>
            </div>
            <div className="flex justify-between items-center py-2 border-b">
              <span className="text-gray-600">Saldo Sanción:</span>
              <span className="font-medium text-red-600">
                ${resumen.saldo_sancion.toLocaleString()}
              </span>
            </div>
            <div className="flex justify-between items-center py-2 font-bold text-lg">
              <span className="text-gray-900">Saldo Total:</span>
              <span className={resumen.saldo_final === 0 ? "text-green-600" : "text-red-600"}>
                ${resumen.saldo_final.toLocaleString()}
              </span>
            </div>
            {resumen.saldo_final === 0 && (
              <div className="p-3 bg-green-50 rounded-md">
                <p className="text-sm text-green-700 flex items-center gap-2">
                  <CheckCircle size={16} />
                  ¡Liquidación completada! No hay saldos pendientes.
                </p>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Summary Statistics */}
        <Card>
          <CardHeader>
            <CardTitle>Estadísticas de Liquidación</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2 text-sm">
              <div className="flex justify-between py-1">
                <span className="text-gray-600">Total de Pagos:</span>
                <span className="font-medium">{historial.length}</span>
              </div>
              <div className="flex justify-between py-1">
                <span className="text-gray-600">Primer Pago:</span>
                <span className="font-medium">{historial[0]?.fecha_pago}</span>
              </div>
              <div className="flex justify-between py-1">
                <span className="text-gray-600">Último Pago:</span>
                <span className="font-medium">{historial[historial.length - 1]?.fecha_pago}</span>
              </div>
              <div className="flex justify-between py-1 border-t pt-2">
                <span className="text-gray-600">Promedio Tasa:</span>
                <span className="font-medium">
                  {(historial.reduce((sum, p) => sum + p.tasa_aplicada, 0) / historial.length * 100).toFixed(2)}%
                </span>
              </div>
              <div className="flex justify-between py-1">
                <span className="text-gray-600">Total Días Mora:</span>
                <span className="font-medium">
                  {historial.reduce((sum, p) => sum + p.dias_mora, 0)} días
                </span>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
