import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Upload, Settings, Save, CheckCircle } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { ConfiguracionProporciones } from "@/lib/types";

const proportionSchema = z.object({
  proporciones: z.object({
    p1: z.object({
      impuesto: z.number().min(0).max(1),
      intereses: z.number().min(0).max(1),
      sancion: z.number().min(0).max(1)
    }),
    p2: z.object({
      impuesto: z.number().min(0).max(1),
      intereses: z.number().min(0).max(1),
      sancion: z.number().min(0).max(1)
    }),
    p3: z.object({
      impuesto: z.number().min(0).max(1),
      intereses: z.number().min(0).max(1),
      sancion: z.number().min(0).max(1)
    })
  })
});

type ProportionFormData = z.infer<typeof proportionSchema>;

export default function ConfiguracionTab() {
  const { toast } = useToast();
  const [uploadStatus, setUploadStatus] = useState<{
    tasas: boolean;
    ipc: boolean;
  }>({ tasas: true, ipc: true }); // Assuming files are loaded by default

  const { data: configuracion, refetch } = useQuery({
    queryKey: ["/api/configuracion"],
  });

  const form = useForm<ProportionFormData>({
    resolver: zodResolver(proportionSchema),
    defaultValues: {
      proporciones: {
        p1: { impuesto: 0.6, intereses: 0.25, sancion: 0.15 },
        p2: { impuesto: 0.3, intereses: 0.5, sancion: 0.2 },
        p3: { impuesto: 0.25, intereses: 0.25, sancion: 0.5 }
      }
    }
  });

  const saveConfiguration = useMutation({
    mutationFn: async (data: ConfiguracionProporciones) => {
      const response = await apiRequest("POST", "/api/configuracion", { proporciones: data });
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Configuración guardada",
        description: "Las proporciones han sido actualizadas correctamente."
      });
      refetch();
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Error al guardar la configuración.",
        variant: "destructive"
      });
    }
  });

  const uploadFile = async (file: File, type: "tasas" | "ipc") => {
    try {
      const formData = new FormData();
      formData.append("file", file);

      const response = await fetch(`/api/upload/${type}`, {
        method: "POST",
        body: formData,
        credentials: "include"
      });

      if (!response.ok) {
        throw new Error("Upload failed");
      }

      setUploadStatus(prev => ({ ...prev, [type]: true }));
      toast({
        title: "Archivo cargado",
        description: `El archivo ${type === "tasas" ? "de tasas DIAN" : "de IPC"} se ha cargado correctamente.`
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Error al cargar el archivo.",
        variant: "destructive"
      });
    }
  };

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>, type: "tasas" | "ipc") => {
    const file = event.target.files?.[0];
    if (file) {
      uploadFile(file, type);
    }
  };

  const onSubmit = (data: ProportionFormData) => {
    saveConfiguration.mutate(data.proporciones);
  };

  // Update form when configuration is loaded
  if (configuracion && !form.formState.isDirty) {
    form.reset({ proporciones: configuracion.proporciones });
  }

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
      {/* File Upload Card */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Upload className="text-blue-600" size={20} />
            Cargar Archivos de Datos
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* DIAN Rates Upload */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Archivo de Tasas DIAN (CSV)
            </label>
            <div className="mt-1 flex justify-center px-6 pt-5 pb-6 border-2 border-gray-300 border-dashed rounded-md hover:border-blue-400 transition-colors cursor-pointer">
              <div className="space-y-1 text-center">
                <svg className="w-12 h-12 text-gray-400 mx-auto" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M14,2H6A2,2 0 0,0 4,4V20A2,2 0 0,0 6,22H18A2,2 0 0,0 20,20V8L14,2M18,20H6V4H13V9H18V20Z" />
                </svg>
                <div className="flex text-sm text-gray-600">
                  <label htmlFor="tasas-upload" className="relative cursor-pointer bg-white rounded-md font-medium text-blue-600 hover:text-blue-500">
                    <span>Cargar archivo</span>
                    <input
                      id="tasas-upload"
                      name="tasas-upload"
                      type="file"
                      accept=".csv"
                      className="sr-only"
                      onChange={(e) => handleFileUpload(e, "tasas")}
                    />
                  </label>
                  <p className="pl-1">o arrastra y suelta</p>
                </div>
                <p className="text-xs text-gray-500">CSV hasta 10MB</p>
              </div>
            </div>
            {uploadStatus.tasas && (
              <div className="mt-2 flex items-center text-sm text-green-600">
                <CheckCircle className="mr-2" size={16} />
                tasas_dian.csv cargado correctamente
              </div>
            )}
          </div>

          {/* IPC Upload */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Archivo de IPC (CSV)
            </label>
            <div className="mt-1 flex justify-center px-6 pt-5 pb-6 border-2 border-gray-300 border-dashed rounded-md hover:border-blue-400 transition-colors cursor-pointer">
              <div className="space-y-1 text-center">
                <svg className="w-12 h-12 text-gray-400 mx-auto" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M14,2H6A2,2 0 0,0 4,4V20A2,2 0 0,0 6,22H18A2,2 0 0,0 20,20V8L14,2M18,20H6V4H13V9H18V20Z" />
                </svg>
                <div className="flex text-sm text-gray-600">
                  <label htmlFor="ipc-upload" className="relative cursor-pointer bg-white rounded-md font-medium text-blue-600 hover:text-blue-500">
                    <span>Cargar archivo</span>
                    <input
                      id="ipc-upload"
                      name="ipc-upload"
                      type="file"
                      accept=".csv"
                      className="sr-only"
                      onChange={(e) => handleFileUpload(e, "ipc")}
                    />
                  </label>
                  <p className="pl-1">o arrastra y suelta</p>
                </div>
                <p className="text-xs text-gray-500">CSV hasta 10MB</p>
              </div>
            </div>
            {uploadStatus.ipc && (
              <div className="mt-2 flex items-center text-sm text-green-600">
                <CheckCircle className="mr-2" size={16} />
                ipc.csv cargado correctamente
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Proportion Settings Card */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Settings className="text-blue-600" size={20} />
            Configuración de Proporciones
          </CardTitle>
        </CardHeader>
        <CardContent>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
              
              {/* Proportion 1 */}
              <div className="p-4 bg-gray-50 rounded-md">
                <h4 className="font-medium text-gray-900 mb-3">Proporción 1: Impuesto Mayor</h4>
                <div className="grid grid-cols-3 gap-3">
                  <FormField
                    control={form.control}
                    name="proporciones.p1.impuesto"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-xs text-gray-600">Impuesto %</FormLabel>
                        <FormControl>
                          <Input
                            type="number"
                            step={0.01}
                            min={0}
                            max={1}
                            {...field}
                            onChange={(e) => field.onChange(parseFloat(e.target.value))}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="proporciones.p1.intereses"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-xs text-gray-600">Intereses %</FormLabel>
                        <FormControl>
                          <Input
                            type="number"
                            step={0.01}
                            min={0}
                            max={1}
                            {...field}
                            onChange={(e) => field.onChange(parseFloat(e.target.value))}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="proporciones.p1.sancion"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-xs text-gray-600">Sanción %</FormLabel>
                        <FormControl>
                          <Input
                            type="number"
                            step={0.01}
                            min={0}
                            max={1}
                            {...field}
                            onChange={(e) => field.onChange(parseFloat(e.target.value))}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
              </div>

              {/* Proportion 2 */}
              <div className="p-4 bg-gray-50 rounded-md">
                <h4 className="font-medium text-gray-900 mb-3">Proporción 2: Interés Mayor</h4>
                <div className="grid grid-cols-3 gap-3">
                  <FormField
                    control={form.control}
                    name="proporciones.p2.impuesto"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-xs text-gray-600">Impuesto %</FormLabel>
                        <FormControl>
                          <Input
                            type="number"
                            step={0.01}
                            min={0}
                            max={1}
                            {...field}
                            onChange={(e) => field.onChange(parseFloat(e.target.value))}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="proporciones.p2.intereses"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-xs text-gray-600">Intereses %</FormLabel>
                        <FormControl>
                          <Input
                            type="number"
                            step={0.01}
                            min={0}
                            max={1}
                            {...field}
                            onChange={(e) => field.onChange(parseFloat(e.target.value))}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="proporciones.p2.sancion"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-xs text-gray-600">Sanción %</FormLabel>
                        <FormControl>
                          <Input
                            type="number"
                            step={0.01}
                            min={0}
                            max={1}
                            {...field}
                            onChange={(e) => field.onChange(parseFloat(e.target.value))}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
              </div>

              {/* Proportion 3 */}
              <div className="p-4 bg-gray-50 rounded-md">
                <h4 className="font-medium text-gray-900 mb-3">Proporción 3: Sanción Mayor</h4>
                <div className="grid grid-cols-3 gap-3">
                  <FormField
                    control={form.control}
                    name="proporciones.p3.impuesto"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-xs text-gray-600">Impuesto %</FormLabel>
                        <FormControl>
                          <Input
                            type="number"
                            step={0.01}
                            min={0}
                            max={1}
                            {...field}
                            onChange={(e) => field.onChange(parseFloat(e.target.value))}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="proporciones.p3.intereses"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-xs text-gray-600">Intereses %</FormLabel>
                        <FormControl>
                          <Input
                            type="number"
                            step={0.01}
                            min={0}
                            max={1}
                            {...field}
                            onChange={(e) => field.onChange(parseFloat(e.target.value))}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="proporciones.p3.sancion"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-xs text-gray-600">Sanción %</FormLabel>
                        <FormControl>
                          <Input
                            type="number"
                            step={0.01}
                            min={0}
                            max={1}
                            {...field}
                            onChange={(e) => field.onChange(parseFloat(e.target.value))}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
              </div>

              <Button 
                type="submit" 
                className="w-full"
                disabled={saveConfiguration.isPending}
              >
                <Save className="mr-2" size={16} />
                {saveConfiguration.isPending ? "Guardando..." : "Guardar Configuración"}
              </Button>
            </form>
          </Form>
        </CardContent>
      </Card>
    </div>
  );
}
