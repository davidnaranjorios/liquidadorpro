import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertLiquidacionSchema, insertConfiguracionSchema } from "@shared/schema";
import multer from "multer";
import path from "path";
import fs from "fs";
import { spawn } from "child_process";

const upload = multer({ dest: 'uploads/' });

export async function registerRoutes(app: Express): Promise<Server> {
  
  // Get configuration
  app.get("/api/configuracion", async (req, res) => {
    try {
      const config = await storage.getConfiguracion();
      res.json(config);
    } catch (error) {
      res.status(500).json({ message: "Error al obtener configuración" });
    }
  });

  // Save configuration
  app.post("/api/configuracion", async (req, res) => {
    try {
      const validated = insertConfiguracionSchema.parse(req.body);
      const config = await storage.saveConfiguracion(validated);
      res.json(config);
    } catch (error) {
      res.status(400).json({ message: "Error al guardar configuración" });
    }
  });

  // Upload CSV files
  app.post("/api/upload/:type", upload.single('file'), async (req, res) => {
    try {
      const { type } = req.params;
      if (!req.file) {
        return res.status(400).json({ message: "No se proporcionó archivo" });
      }

      const allowedTypes = ['tasas', 'ipc'];
      if (!allowedTypes.includes(type)) {
        return res.status(400).json({ message: "Tipo de archivo no válido" });
      }

      // Move file to data directory
      const dataDir = path.join(__dirname, 'data');
      if (!fs.existsSync(dataDir)) {
        fs.mkdirSync(dataDir, { recursive: true });
      }

      const fileName = type === 'tasas' ? 'tasas_dian.csv' : 'ipc.csv';
      const destPath = path.join(dataDir, fileName);
      
      fs.copyFileSync(req.file.path, destPath);
      fs.unlinkSync(req.file.path);

      res.json({ message: `Archivo ${fileName} cargado correctamente` });
    } catch (error) {
      res.status(500).json({ message: "Error al cargar archivo" });
    }
  });

  // Create liquidation
  app.post("/api/liquidacion", async (req, res) => {
    try {
      const validated = insertLiquidacionSchema.parse(req.body);
      const liquidacion = await storage.createLiquidacion(validated);
      res.json(liquidacion);
    } catch (error) {
      res.status(400).json({ message: "Error al crear liquidación" });
    }
  });

  // Calculate liquidation
  app.post("/api/liquidacion/:id/calcular", async (req, res) => {
    try {
      const { id } = req.params;
      const liquidacion = await storage.getLiquidacion(parseInt(id));
      
      if (!liquidacion) {
        return res.status(404).json({ message: "Liquidación no encontrada" });
      }

      // Call Python calculation script
      const pythonScript = path.join(__dirname, 'liquidation', 'calculate.py');
      const dataPath = path.join(__dirname, 'data');
      
      // Use the full path to python from the virtual environment
      const pythonPath = '/home/runner/workspace/.pythonlibs/bin/python';
      const pythonProcess = spawn(pythonPath, [pythonScript], {
        stdio: ['pipe', 'pipe', 'pipe'],
        cwd: path.join(__dirname, 'liquidation')
      });

      const inputData = JSON.stringify({
        ...liquidacion,
        dataPath
      });

      pythonProcess.stdin.write(inputData);
      pythonProcess.stdin.end();

      let resultData = '';
      let errorData = '';

      pythonProcess.stdout.on('data', (data) => {
        resultData += data.toString();
      });

      pythonProcess.stderr.on('data', (data) => {
        errorData += data.toString();
      });

      pythonProcess.on('close', async (code) => {
        console.log('Python process exit code:', code);
        console.log('Python stdout:', resultData);
        console.log('Python stderr:', errorData);
        
        if (code !== 0) {
          console.error('Python script error:', errorData);
          return res.status(500).json({ 
            message: "Error en cálculo de liquidación",
            error: errorData,
            stdout: resultData 
          });
        }

        try {
          const results = JSON.parse(resultData);
          await storage.updateLiquidacionResultados(parseInt(id), results);
          res.json(results);
        } catch (parseError) {
          console.error('Parse error:', parseError);
          console.error('Raw data:', resultData);
          res.status(500).json({ 
            message: "Error al procesar resultados",
            error: parseError instanceof Error ? parseError.message : String(parseError),
            data: resultData 
          });
        }
      });

    } catch (error) {
      res.status(500).json({ message: "Error al calcular liquidación" });
    }
  });

  // Get liquidation results
  app.get("/api/liquidacion/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const liquidacion = await storage.getLiquidacion(parseInt(id));
      
      if (!liquidacion) {
        return res.status(404).json({ message: "Liquidación no encontrada" });
      }

      res.json(liquidacion);
    } catch (error) {
      res.status(500).json({ message: "Error al obtener liquidación" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
