#!/usr/bin/env python3
import sys
import json
import os
from datetime import datetime
import pandas as pd
import math

# Import our modules
import sys
import os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from tasas import cargar_tasas, obtener_tasa_base
from ipc import cargar_ipc, obtener_incremento_ipc_compuesto

def redondear_mas(valor):
    return int(math.ceil(valor / 1000.0)) * 1000

def main():
    try:
        # Read input from stdin
        input_data = sys.stdin.read().strip()
        if not input_data:
            print(json.dumps({"error": "No input data provided"}))
            return
            
        data = json.loads(input_data)
        
        # Initialize data files
        data_path = data['dataPath']
        tasas_path = os.path.join(data_path, 'tasas_dian.csv')
        ipc_path = os.path.join(data_path, 'ipc.csv')
        
        if not os.path.exists(tasas_path) or not os.path.exists(ipc_path):
            print(json.dumps({"error": "Data files not found"}))
            return
        
        cargar_tasas(tasas_path)
        cargar_ipc(ipc_path)
        
        # Extract data
        nit = data['nit']
        razon_social = data['razonSocial']
        concepto = data['concepto']
        anio = data['anio']
        periodo = data['periodo']
        valor_inicial = data['valorInicial']
        saldo_impuesto = valor_inicial
        saldo_sancion = data['valorSancion']
        origen_sancion = data['origenSancion']
        fecha_vencimiento = datetime.strptime(data['fechaVencimiento'], '%Y-%m-%d')
        fecha_presentacion_sancion = datetime.strptime(data['fechaPresentacionSancion'], '%Y-%m-%d')
        tipo_norma = data['tipoNorma']
        pagos = data['pagos']
    except Exception as e:
        print(json.dumps({"error": f"Error processing input: {str(e)}"}))
        return
    
    saldo_intereses = 0.0
    historial = []
    
    anio_liquidacion = fecha_presentacion_sancion.year
    ultimo_anio_actualizado = anio_liquidacion
    
    for pago in pagos:
        # Handle different date formats
        try:
            fecha_pago = datetime.strptime(pago['fecha'], '%Y-%m-%d')
        except ValueError:
            try:
                fecha_pago = datetime.strptime(pago['fecha'], '%d/%m/%Y')
            except ValueError:
                fecha_pago = datetime.strptime(pago['fecha'], '%Y/%m/%d')
        monto_pago = pago['valor']
        dias_mora = max(0, (fecha_pago - fecha_vencimiento).days)
        
        # Get rate for this date
        tasa = obtener_tasa_base(fecha_pago)
        if tasa is None:
            tasa = 0.0
        
        intereses = round(saldo_impuesto * tasa * dias_mora / 365)
        saldo_intereses = intereses
        
        # Update sanction by IPC
        if fecha_pago.year > ultimo_anio_actualizado:
            if (origen_sancion.lower() == 'privada' and fecha_pago.year > anio_liquidacion + 1) or \
               (origen_sancion.lower() == 'oficial' and fecha_pago.year > anio_liquidacion):
                incremento = obtener_incremento_ipc_compuesto(ultimo_anio_actualizado, fecha_pago.year)
                saldo_sancion = round(saldo_sancion * (1 + incremento))
                ultimo_anio_actualizado = fecha_pago.year
        
        total_deuda = saldo_impuesto + saldo_intereses + saldo_sancion
        if total_deuda == 0:
            factor = 0
        else:
            factor = round(round(monto_pago * 100 / total_deuda, 4) / 100, 4)
        
        vi, inte, sanc = saldo_impuesto, saldo_intereses, saldo_sancion
        if vi > inte:
            tipo_proporcion = "Proporción 1: Impuesto mayor" if vi > sanc else "Proporción 3: Sanción mayor"
        else:
            tipo_proporcion = "Proporción 2: Interes mayor" if inte > sanc else "Proporción 3: Sanción mayor"
        
        if tipo_proporcion == "Proporción 1: Impuesto mayor":
            intereses_pago = redondear_mas(factor * saldo_intereses)
            sancion_pago = redondear_mas(factor * saldo_sancion)
            impuesto_pago = monto_pago - intereses_pago - sancion_pago if monto_pago < total_deuda else vi
        elif tipo_proporcion == "Proporción 2: Interes mayor":
            impuesto_pago = redondear_mas(factor * saldo_impuesto)
            sancion_pago = redondear_mas(factor * saldo_sancion)
            intereses_pago = monto_pago - impuesto_pago - sancion_pago if monto_pago < total_deuda else inte
        else:
            impuesto_pago = redondear_mas(factor * saldo_impuesto)
            intereses_pago = redondear_mas(factor * saldo_intereses)
            sancion_pago = monto_pago - impuesto_pago - intereses_pago if monto_pago < total_deuda else sanc
        
        # Update balances
        saldo_impuesto = max(0, saldo_impuesto - impuesto_pago)
        saldo_intereses = max(0, saldo_intereses - intereses_pago)
        saldo_sancion = max(0, saldo_sancion - sancion_pago)
        
        historial.append({
            'fecha_pago': fecha_pago.strftime('%d/%m/%Y'),
            'monto_pago': monto_pago,
            'tipo_proporcion': tipo_proporcion,
            'factor_proporcionalidad': factor,
            'impuesto_proporcion': impuesto_pago,
            'intereses_proporcion': intereses_pago,
            'sancion_proporcion': sancion_pago,
            'impuesto_saldo': saldo_impuesto,
            'intereses_saldo': saldo_intereses,
            'sancion_saldo': saldo_sancion,
            'tasa_aplicada': tasa,
            'dias_mora': dias_mora
        })
    
    # Calculate summary
    total_pagado = sum(pago['valor'] for pago in pagos)
    saldo_final = saldo_impuesto + saldo_intereses + saldo_sancion
    
    result = {
        'historial': historial,
        'resumen': {
            'impuesto_base': valor_inicial,
            'intereses_totales': sum(p['intereses_proporcion'] for p in historial),
            'sanciones_totales': sum(p['sancion_proporcion'] for p in historial),
            'total_pagado': total_pagado,
            'saldo_impuesto': saldo_impuesto,
            'saldo_intereses': saldo_intereses,
            'saldo_sancion': saldo_sancion,
            'saldo_final': saldo_final
        }
    }
    
    print(json.dumps(result))

if __name__ == "__main__":
    main()
