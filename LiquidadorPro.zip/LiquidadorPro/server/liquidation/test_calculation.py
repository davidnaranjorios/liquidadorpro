#!/usr/bin/env python3
import json
import os
from datetime import datetime

# Test the calculation with sample data
test_data = {
    "nit": "123456789",
    "razonSocial": "Test Company",
    "concepto": "IVA",
    "anio": 2024,
    "periodo": 1,
    "valorInicial": 1000000,
    "valorSancion": 100000,
    "origenSancion": "Privada",
    "fechaVencimiento": "2024-01-15",
    "fechaPresentacionSancion": "2024-01-20",
    "tipoNorma": "TASA DIAN",
    "pagos": [
        {"fecha": "2024-02-15", "valor": 500000}
    ],
    "dataPath": os.path.join(os.path.dirname(__file__), '..', 'data')
}

print(json.dumps(test_data))