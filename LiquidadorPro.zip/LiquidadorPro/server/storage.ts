import { liquidaciones, configuraciones, type Liquidacion, type InsertLiquidacion, type Configuracion, type InsertConfiguracion } from "@shared/schema";

export interface IStorage {
  createLiquidacion(liquidacion: InsertLiquidacion): Promise<Liquidacion>;
  getLiquidacion(id: number): Promise<Liquidacion | undefined>;
  updateLiquidacionResultados(id: number, resultados: any): Promise<void>;
  getConfiguracion(): Promise<Configuracion | undefined>;
  saveConfiguracion(configuracion: InsertConfiguracion): Promise<Configuracion>;
}

export class MemStorage implements IStorage {
  private liquidaciones: Map<number, Liquidacion>;
  private configuraciones: Map<number, Configuracion>;
  private currentLiquidacionId: number;
  private currentConfigId: number;

  constructor() {
    this.liquidaciones = new Map();
    this.configuraciones = new Map();
    this.currentLiquidacionId = 1;
    this.currentConfigId = 1;

    // Default configuration
    const defaultConfig: Configuracion = {
      id: 1,
      proporciones: {
        p1: { impuesto: 0.6, intereses: 0.25, sancion: 0.15 },
        p2: { impuesto: 0.3, intereses: 0.5, sancion: 0.2 },
        p3: { impuesto: 0.25, intereses: 0.25, sancion: 0.5 }
      },
      updatedAt: new Date()
    };
    this.configuraciones.set(1, defaultConfig);
  }

  async createLiquidacion(insertLiquidacion: InsertLiquidacion): Promise<Liquidacion> {
    const id = this.currentLiquidacionId++;
    const liquidacion: Liquidacion = {
      ...insertLiquidacion,
      id,
      resultados: null,
      createdAt: new Date()
    };
    this.liquidaciones.set(id, liquidacion);
    return liquidacion;
  }

  async getLiquidacion(id: number): Promise<Liquidacion | undefined> {
    return this.liquidaciones.get(id);
  }

  async updateLiquidacionResultados(id: number, resultados: any): Promise<void> {
    const liquidacion = this.liquidaciones.get(id);
    if (liquidacion) {
      liquidacion.resultados = resultados;
      this.liquidaciones.set(id, liquidacion);
    }
  }

  async getConfiguracion(): Promise<Configuracion | undefined> {
    return Array.from(this.configuraciones.values())[0];
  }

  async saveConfiguracion(insertConfiguracion: InsertConfiguracion): Promise<Configuracion> {
    const config: Configuracion = {
      ...insertConfiguracion,
      id: 1,
      updatedAt: new Date()
    };
    this.configuraciones.set(1, config);
    return config;
  }
}

export const storage = new MemStorage();
