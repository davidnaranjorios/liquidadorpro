import { pgTable, text, serial, integer, real, timestamp, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const liquidaciones = pgTable("liquidaciones", {
  id: serial("id").primaryKey(),
  nit: text("nit").notNull(),
  razonSocial: text("razon_social").notNull(),
  concepto: text("concepto").notNull(),
  anio: integer("anio").notNull(),
  periodo: integer("periodo").notNull(),
  valorInicial: real("valor_inicial").notNull(),
  valorSancion: real("valor_sancion").notNull(),
  origenSancion: text("origen_sancion").notNull(),
  fechaVencimiento: text("fecha_vencimiento").notNull(),
  fechaPresentacionSancion: text("fecha_presentacion_sancion").notNull(),
  tipoNorma: text("tipo_norma").notNull(),
  pagos: jsonb("pagos").$type<Array<{ fecha: string; valor: number }>>().notNull(),
  resultados: jsonb("resultados").$type<any>(),
  createdAt: timestamp("created_at").defaultNow(),
});

export const configuraciones = pgTable("configuraciones", {
  id: serial("id").primaryKey(),
  proporciones: jsonb("proporciones").$type<{
    p1: { impuesto: number; intereses: number; sancion: number };
    p2: { impuesto: number; intereses: number; sancion: number };
    p3: { impuesto: number; intereses: number; sancion: number };
  }>().notNull(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const insertLiquidacionSchema = createInsertSchema(liquidaciones).omit({
  id: true,
  createdAt: true,
  resultados: true,
});

export const insertConfiguracionSchema = createInsertSchema(configuraciones).omit({
  id: true,
  updatedAt: true,
});

export type InsertLiquidacion = z.infer<typeof insertLiquidacionSchema>;
export type Liquidacion = typeof liquidaciones.$inferSelect;
export type InsertConfiguracion = z.infer<typeof insertConfiguracionSchema>;
export type Configuracion = typeof configuraciones.$inferSelect;
